extends Node
# Voice chat.
# Sending: microphone -> hidden audio bus with a capture effect -> 16 kHz mono 16-bit chunks (20 ms)
#          -> signal chunk_ready (main.gd passes it to Net, which sends it to the host / the other guests).
# Playing: play_chunk(sender id, pcm) -> one AudioStreamGenerator player per speaker.
# Needs: project setting audio/driver/enable_input = true and the RECORD_AUDIO permission on Android.

signal chunk_ready(pcm: PackedByteArray)

const VOICE_RATE := 16000
const CHUNK_SAMPLES := 320             # 20 ms at 16 kHz
const MIC_GAIN := 2.0
const VAD_THRESHOLD := 0.012           # microphone peak that counts as speech (silence is not sent)
const VAD_HANGOVER := 0.4              # keep sending this long after the last speech
const BUS_NAME := "VoiceCapture"
const MAX_BUFFER_FRAMES := 5600        # 0.35 s; if more is waiting, new audio is dropped to keep the delay low
const PREROLL_FRAMES := 640            # 40 ms of silence before a new phrase, against crackling
const SPEAK_WINDOW_MS := 500

var level := 0.0                       # 0..1 microphone level for the indicator

var _active := false
var _capture: AudioEffectCapture
var _mic_player: AudioStreamPlayer
var _pos := 0.0
var _sum := 0.0
var _cnt := 0
var _pending := PackedFloat32Array()
var _hang := 0.0
var _players := {}                     # sender id -> {player, pb, cap}
var _last_heard := {}                  # sender id -> ticks (ms)
var _guest_nums := {}


func _ready() -> void:
	multiplayer.peer_disconnected.connect(_on_peer_gone)


func is_mic_on() -> bool:
	return _active


# Starts the microphone. Returns "" on success or the reason on failure.
func start_mic() -> String:
	if _active:
		return ""
	if not bool(ProjectSettings.get_setting("audio/driver/enable_input", false)):
		return "В проекте выключена настройка audio/driver/enable_input"
	if not await _ensure_permission():
		return "Нет доступа к микрофону. Разреши «Микрофон» для приложения в настройках телефона"
	_setup_bus()
	if _mic_player == null:
		_mic_player = AudioStreamPlayer.new()
		_mic_player.stream = AudioStreamMicrophone.new()
		_mic_player.bus = BUS_NAME
		add_child(_mic_player)
	for attempt in 3:
		_mic_player.play()
		await get_tree().create_timer(0.3).timeout
		if _mic_player.playing:
			break
		_mic_player.stop()
	if not _mic_player.playing:
		return "Микрофон не запустился. Проверь разрешение «Микрофон» и что его не занимает другое приложение"
	_capture.clear_buffer()
	_reset_encoder()
	_active = true
	return ""


func stop_mic() -> void:
	_active = false
	if _mic_player and _mic_player.playing:
		_mic_player.stop()
	_reset_encoder()
	level = 0.0


# Stops the microphone and all speakers (when leaving a room).
func stop_all() -> void:
	stop_mic()
	for id in _players.keys():
		_free_player(id)
	_last_heard.clear()
	_guest_nums.clear()


func _reset_encoder() -> void:
	_pos = 0.0
	_sum = 0.0
	_cnt = 0
	_hang = 0.0
	_pending.clear()


func _ensure_permission() -> bool:
	if OS.get_name() != "Android":
		return true
	if "android.permission.RECORD_AUDIO" in OS.get_granted_permissions():
		return true
	if OS.request_permission("RECORD_AUDIO"):
		return true
	# The system dialog is open now. Wait until the user answers (up to 30 s).
	var waited := 0.0
	while waited < 30.0:
		await get_tree().create_timer(0.3).timeout
		waited += 0.3
		if "android.permission.RECORD_AUDIO" in OS.get_granted_permissions():
			return true
	return false


# Hidden bus: capture effect first, then silence (-80 dB), so you do not hear yourself.
func _setup_bus() -> void:
	var idx := AudioServer.get_bus_index(BUS_NAME)
	if idx == -1:
		AudioServer.add_bus()
		idx = AudioServer.bus_count - 1
		AudioServer.set_bus_name(idx, BUS_NAME)
		_capture = AudioEffectCapture.new()
		_capture.buffer_length = 0.3
		AudioServer.add_bus_effect(idx, _capture)
		var amp := AudioEffectAmplify.new()
		amp.volume_db = -80.0
		AudioServer.add_bus_effect(idx, amp)
	elif _capture == null:
		_capture = AudioServer.get_bus_effect(idx, 0) as AudioEffectCapture


func _process(delta: float) -> void:
	if _active and _capture != null:
		_pump_capture(delta)


func _pump_capture(delta: float) -> void:
	var avail := _capture.get_frames_available()
	if avail <= 0:
		return
	var frames: PackedVector2Array = _capture.get_buffer(avail)
	# Resample to 16 kHz mono by averaging (also works as a simple low-pass filter).
	var step := AudioServer.get_mix_rate() / float(VOICE_RATE)
	var peak := 0.0
	for f in frames:
		var s: float = (f.x + f.y) * 0.5
		var a := absf(s)
		if a > peak:
			peak = a
		_sum += s
		_cnt += 1
		_pos += 1.0
		if _pos >= step:
			_pos -= step
			_pending.append(_sum / float(_cnt))
			_sum = 0.0
			_cnt = 0
	level = lerpf(level, clampf(peak * 4.0, 0.0, 1.0), 0.5)
	if peak > VAD_THRESHOLD:
		_hang = VAD_HANGOVER
	else:
		_hang -= delta
	while _pending.size() >= CHUNK_SAMPLES:
		if _hang > 0.0:
			var pcm := PackedByteArray()
			pcm.resize(CHUNK_SAMPLES * 2)
			for i in CHUNK_SAMPLES:
				var v := clampf(_pending[i] * MIC_GAIN, -1.0, 1.0)
				pcm.encode_s16(i * 2, int(v * 32767.0))
			chunk_ready.emit(pcm)
		_pending = _pending.slice(CHUNK_SAMPLES)


# ---------- Playing other people ----------

# Called for every voice chunk that arrives from the network.
func play_chunk(from_id: int, pcm: PackedByteArray) -> void:
	var n := pcm.size() / 2
	if n <= 0 or n > 4000:
		return
	_last_heard[from_id] = Time.get_ticks_msec()
	var e: Dictionary = _players.get(from_id, {})
	if e.is_empty():
		e = _make_player(from_id)
	var pb: AudioStreamGeneratorPlayback = e["pb"]
	var buffered: int = int(e["cap"]) - pb.get_frames_available()
	if buffered > MAX_BUFFER_FRAMES:
		return
	var frames := PackedVector2Array()
	if buffered < 100:
		# New phrase: a short silent lead-in so small network jitter does not crackle.
		frames.resize(PREROLL_FRAMES)
	var base := frames.size()
	frames.resize(base + n)
	for i in n:
		var v := float(pcm.decode_s16(i * 2)) / 32768.0
		frames[base + i] = Vector2(v, v)
	if pb.get_frames_available() >= frames.size():
		pb.push_buffer(frames)


func _make_player(id: int) -> Dictionary:
	var gen := AudioStreamGenerator.new()
	gen.mix_rate = VOICE_RATE
	gen.buffer_length = 0.5
	var p := AudioStreamPlayer.new()
	p.stream = gen
	add_child(p)
	p.play()
	var pb: AudioStreamGeneratorPlayback = p.get_stream_playback()
	var e := {"player": p, "pb": pb, "cap": pb.get_frames_available()}
	_players[id] = e
	return e


func _free_player(id: int) -> void:
	var e: Dictionary = _players.get(id, {})
	if not e.is_empty():
		var p: AudioStreamPlayer = e["player"]
		p.stop()
		p.queue_free()
	_players.erase(id)


func _on_peer_gone(id: int) -> void:
	_free_player(id)
	_last_heard.erase(id)


# Names of the people who spoke during the last half second.
func speaking_names() -> PackedStringArray:
	var out := PackedStringArray()
	var now := Time.get_ticks_msec()
	for id in _last_heard.keys():
		if now - int(_last_heard[id]) < SPEAK_WINDOW_MS:
			out.append(_label_for(int(id)))
	return out


func _label_for(id: int) -> String:
	if id == 1:
		return "Хост"
	if not _guest_nums.has(id):
		_guest_nums[id] = _guest_nums.size() + 1
	return "Гость %d" % int(_guest_nums[id])
