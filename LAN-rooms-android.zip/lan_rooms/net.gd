extends Node
# Autoload "Net". Handles LAN server discovery (UDP broadcast), hosting and joining (ENet).

signal servers_updated(servers: Dictionary)
signal join_result(ok: bool, message: String)
signal host_closed
signal camera_state_changed(on: bool)
signal video_frame_received(jpg: PackedByteArray)
signal voice_received(from_id: int, pcm: PackedByteArray)

const DISCOVERY_PORT := 7001
const BROADCAST_ADDR := "255.255.255.255"
const SERVER_TIMEOUT_MS := 3000

var hosting := false
var port := 7000
var server_name := ""
var server_password := ""
var mic_enabled := false
var client_password := ""
var camera_on := false
var _authed := {}   # peer id -> true, only peers that passed the password check
var _joined := false   # guest side: the host accepted our password

var _listener: PacketPeerUDP
var _sender: PacketPeerUDP
var _found := {}   # ip -> server info dictionary
var _seen := {}    # ip -> last time seen (ms)
var _last_emitted := ""
var _broadcast_left := 0.0
var _broadcast_targets: Array = []


func _ready() -> void:
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)
	multiplayer.peer_disconnected.connect(func(id: int): _authed.erase(id))


func _process(delta: float) -> void:
	if hosting:
		_broadcast_left -= delta
		if _broadcast_left <= 0.0:
			_broadcast_left = 1.0
			_send_broadcast()
	elif _listener and _listener.is_bound():
		_read_listener()


# ---------- Diagnostics ----------

func _res(code: int) -> String:
	return "OK" if code == OK else "ошибка %d (%s)" % [code, error_string(code)]


# Quick self-test of sockets. Returns lines of text for the diagnostics screen.
func run_diagnostics() -> Array:
	var lines: Array = []
	lines.append("Система: %s, %s" % [OS.get_name(), OS.get_model_name()])
	var ver := Engine.get_version_info()
	var cam_ok := int(ver["hex"]) >= 0x040500
	lines.append("Godot: %d.%d.%d. Камера на Android: %s" % [ver["major"], ver["minor"], ver["patch"], "поддерживается" if cam_ok else "НЕ поддерживается (нужен Godot 4.5 или новее)"])

	var ips := PackedStringArray()
	for addr in IP.get_local_addresses():
		var parts := String(addr).split(".")
		if parts.size() == 4 and parts[0].is_valid_int() and parts[0] != "127":
			ips.append(String(addr))
	lines.append("IP телефона: " + (", ".join(ips) if not ips.is_empty() else "не найден (нет Wi-Fi или хотспота?)"))

	var u := PacketPeerUDP.new()
	var e_bind := u.bind(7099, "*")
	lines.append("UDP: открыть порт 7099 - " + _res(e_bind))
	if e_bind == OK:
		u.set_broadcast_enabled(true)
		u.set_dest_address(BROADCAST_ADDR, DISCOVERY_PORT)
		lines.append("UDP: отправить broadcast - " + _res(u.put_packet("test".to_utf8_buffer())))
	u.close()

	var peer := ENetMultiplayerPeer.new()
	var e_srv := peer.create_server(7098, 1)
	lines.append("ENet: создать сервер на порту 7098 - " + _res(e_srv))
	if e_srv == OK:
		peer.close()

	if e_bind != OK and e_srv != OK:
		lines.append("Вывод: сокеты не открываются совсем. Скорее всего, при экспорте в Android не включено разрешение Internet (Project > Export > Android > Permissions).")
	elif e_srv != OK:
		lines.append("Вывод: UDP работает, но ENet-сервер не создаётся. Скинь мне этот экран.")
	else:
		lines.append("Вывод: сокеты работают. Игра использует UDP, а большинство сканеров портов проверяют только TCP, поэтому порт в них может казаться закрытым. Проверяй кнопкой «Сканировать» на втором телефоне в той же сети.")
	return lines


# ---------- Port scan ----------

# Checks which ports can be opened right now. Ports below 1024 usually can't be
# opened by a normal Android app, so the scan starts at 1024 by default.
func scan_free_ports(from_port := 1024, to_port := 10000, want := 80) -> Array:
	var free := []
	for p in range(from_port, to_port + 1):
		if p == DISCOVERY_PORT:
			continue
		var t := ENetMultiplayerPeer.new()
		if t.create_server(p, 1) == OK:
			free.append(p)
			t.close()
			if free.size() >= want:
				break
		if p % 200 == 0:
			await get_tree().process_frame
	return free


# ---------- Discovery ----------

func current_servers() -> Dictionary:
	return _found.duplicate()


# Drops the current list and listens from scratch, so new hosts show up without restarting the app.
func rescan() -> void:
	if hosting:
		return
	_stop_listener()
	start_discovery()


# Global broadcast plus a directed broadcast (x.y.z.255) for every local IPv4 address.
# Directed broadcast is more reliable on phone hotspots.
func _collect_broadcast_targets() -> Array:
	var targets: Array = [BROADCAST_ADDR]
	for addr in IP.get_local_addresses():
		var parts: PackedStringArray = String(addr).split(".")
		if parts.size() != 4 or not parts[0].is_valid_int():
			continue
		if parts[0] == "127" or (parts[0] == "169" and parts[1] == "254"):
			continue
		var t := "%s.%s.%s.255" % [parts[0], parts[1], parts[2]]
		if not targets.has(t):
			targets.append(t)
	return targets


func start_discovery() -> void:
	if _listener and _listener.is_bound():
		return
	_listener = PacketPeerUDP.new()
	if _listener.bind(DISCOVERY_PORT, "*") != OK:
		push_warning("Не удалось слушать порт поиска серверов")
		_listener = null


func _stop_listener() -> void:
	if _listener:
		_listener.close()
	_listener = null
	_found.clear()
	_seen.clear()
	_last_emitted = ""


func _read_listener() -> void:
	var now := Time.get_ticks_msec()
	while _listener.get_available_packet_count() > 0:
		var raw := _listener.get_packet().get_string_from_utf8()
		var ip := _listener.get_packet_ip()
		var data = JSON.parse_string(raw)
		if typeof(data) == TYPE_DICTIONARY and data.get("app") == "lanrooms":
			_found[ip] = data
			_seen[ip] = now
	for ip in _seen.keys():
		if now - _seen[ip] > SERVER_TIMEOUT_MS:
			_seen.erase(ip)
			_found.erase(ip)
	var snapshot := JSON.stringify(_found)
	if snapshot != _last_emitted:
		_last_emitted = snapshot
		servers_updated.emit(_found.duplicate())


func _send_broadcast() -> void:
	if _sender == null:
		return
	var msg := JSON.stringify({
		"app": "lanrooms",
		"v": 1,
		"name": server_name,
		"pw": server_password != "",   # only the flag, never the password
		"mic": mic_enabled,
		"port": port,
		"players": multiplayer.get_peers().size(),
	})
	var payload := msg.to_utf8_buffer()
	for target in _broadcast_targets:
		_sender.set_dest_address(target, DISCOVERY_PORT)
		_sender.put_packet(payload)


# ---------- Hosting ----------

func start_hosting(sname: String, pw: String, mic: bool, server_port: int) -> int:
	leave()
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(server_port, 8)
	if err != OK:
		return err
	multiplayer.multiplayer_peer = peer
	port = server_port
	server_name = sname
	server_password = pw
	mic_enabled = mic
	hosting = true
	_stop_listener()
	_sender = PacketPeerUDP.new()
	_sender.set_broadcast_enabled(true)
	_broadcast_targets = _collect_broadcast_targets()
	_broadcast_left = 0.0
	return OK


func set_camera_state(on: bool) -> void:
	camera_on = on
	if not hosting:
		return
	for id in _authed.keys():
		_camera_state.rpc_id(id, on)


# Sends one JPEG frame to every guest that passed the password check.
func send_video_frame(jpg: PackedByteArray) -> void:
	if not hosting:
		return
	for id in _authed.keys():
		_video_frame.rpc_id(id, jpg)


# ---------- Joining ----------

func join_server(ip: String, server_port: int, pw: String) -> void:
	var peer := ENetMultiplayerPeer.new()
	if peer.create_client(ip, server_port) != OK:
		join_result.emit(false, "Не удалось подключиться")
		return
	client_password = pw
	hosting = false
	_stop_listener()
	multiplayer.multiplayer_peer = peer


# ---------- Shared ----------

func leave() -> void:
	hosting = false
	camera_on = false
	_joined = false
	_authed.clear()
	if _sender:
		_sender.close()
	_sender = null
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()


func _on_connected_to_server() -> void:
	_auth.rpc_id(1, client_password)


func _on_connection_failed() -> void:
	join_result.emit(false, "Не удалось подключиться")
	leave()


func _on_server_disconnected() -> void:
	if not hosting:
		host_closed.emit()
		leave()


@rpc("any_peer", "reliable")
func _auth(pw: String) -> void:
	var id := multiplayer.get_remote_sender_id()
	if server_password != "" and pw != server_password:
		_auth_result.rpc_id(id, false)
		get_tree().create_timer(0.5).timeout.connect(_kick.bind(id))
		return
	_authed[id] = true
	_auth_result.rpc_id(id, true)
	_camera_state.rpc_id(id, camera_on)


func _kick(id: int) -> void:
	if multiplayer.multiplayer_peer:
		multiplayer.multiplayer_peer.disconnect_peer(id)


@rpc("authority", "reliable")
func _auth_result(ok: bool) -> void:
	if ok:
		_joined = true
		join_result.emit(true, "Подключено")
	else:
		join_result.emit(false, "Неверный пароль")
		leave()


@rpc("authority", "reliable")
func _camera_state(on: bool) -> void:
	camera_state_changed.emit(on)


@rpc("authority", "call_remote", "unreliable")
func _video_frame(jpg: PackedByteArray) -> void:
	video_frame_received.emit(jpg)


# ---------- Voice ----------
# Everyone sends voice to the host, the host passes it on to the other guests.

# Sends one voice chunk (16 kHz mono 16-bit PCM). Host: to every guest. Guest: to the host.
func send_voice(pcm: PackedByteArray) -> void:
	if hosting:
		for id in _authed.keys():
			_voice_down.rpc_id(id, 1, pcm)
	elif _joined:
		_voice_up.rpc_id(1, pcm)


@rpc("any_peer", "call_remote", "unreliable")
func _voice_up(pcm: PackedByteArray) -> void:
	if not hosting:
		return
	var from := multiplayer.get_remote_sender_id()
	if not _authed.has(from) or pcm.size() > 8000:
		return
	voice_received.emit(from, pcm)   # the host hears the guest
	for id in _authed.keys():
		if id != from:
			_voice_down.rpc_id(id, from, pcm)


@rpc("authority", "call_remote", "unreliable")
func _voice_down(from_id: int, pcm: PackedByteArray) -> void:
	voice_received.emit(from_id, pcm)
