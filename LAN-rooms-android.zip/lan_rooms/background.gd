extends Control
# Live background with several modes. Switch with set_mode(index).
# Idea for later: custom modes loaded from .json files.

enum Mode { HONEYCOMB, STARS, DATA_RAIN, BUBBLES, OFF }
const MODE_NAMES := ["Соты сети", "Звёздный полёт", "Дождь данных", "Пузыри", "Без обоев"]

const HEX_R := 64.0
const NODE_COUNT := 26
const LINK_DIST := 260.0
const STAR_COUNT := 110
const RAIN_COL_W := 36.0
const RAIN_STEP := 22.0
const BUBBLE_COUNT := 16

const BLUE := Color(0.427, 0.655, 0.925)
const ORANGE := Color(0.851, 0.467, 0.341)
const PURPLE := Color(0.62, 0.52, 0.91)

var mode: int = Mode.HONEYCOMB
var _view := Vector2(720, 1600)
var _t := 0.0
var _rng := RandomNumberGenerator.new()

# honeycomb
var _hex_lines := PackedVector2Array()
var _hex_centers: Array[Vector2] = []
var _glow := {}
var _nodes: Array = []
var _spawn_left := 0.0
# stars
var _stars: Array = []
# data rain
var _cols: Array = []
# bubbles
var _bubbles: Array = []


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(PRESET_FULL_RECT)
	_view = get_viewport_rect().size
	_rng.randomize()
	_build_hex_grid()
	set_mode(mode)


func set_mode(m: int) -> void:
	mode = m
	_glow.clear()
	match mode:
		Mode.HONEYCOMB:
			_init_honeycomb()
		Mode.STARS:
			_init_stars()
		Mode.DATA_RAIN:
			_init_rain()
		Mode.BUBBLES:
			_init_bubbles()
	set_process(mode != Mode.OFF)
	queue_redraw()


func _process(delta: float) -> void:
	_t += delta
	match mode:
		Mode.HONEYCOMB:
			_update_honeycomb(delta)
		Mode.STARS:
			_update_stars(delta)
		Mode.DATA_RAIN:
			_update_rain(delta)
		Mode.BUBBLES:
			_update_bubbles(delta)
	queue_redraw()


func _draw() -> void:
	match mode:
		Mode.HONEYCOMB:
			_draw_honeycomb()
		Mode.STARS:
			_draw_stars()
		Mode.DATA_RAIN:
			_draw_rain()
		Mode.BUBBLES:
			_draw_bubbles()


# ================= Honeycomb network =================

func _build_hex_grid() -> void:
	_hex_lines.clear()
	_hex_centers.clear()
	var w := sqrt(3.0) * HEX_R
	var rows := int(_view.y / (HEX_R * 1.5)) + 3
	var cols := int(_view.x / w) + 3
	for r in range(-1, rows):
		for c in range(-1, cols):
			var center := Vector2(c * w + (r % 2) * w * 0.5, r * HEX_R * 1.5)
			_hex_centers.append(center)
			var pts: Array[Vector2] = []
			for i in 6:
				pts.append(center + Vector2.from_angle(PI / 6.0 + i * PI / 3.0) * HEX_R)
			for i in 6:
				_hex_lines.append(pts[i])
				_hex_lines.append(pts[(i + 1) % 6])


func _init_honeycomb() -> void:
	_nodes.clear()
	for i in NODE_COUNT:
		_nodes.append({
			"pos": Vector2(_rng.randf() * _view.x, _rng.randf() * _view.y),
			"vel": Vector2.from_angle(_rng.randf() * TAU) * _rng.randf_range(12.0, 34.0),
			"hot": i % 6 == 0,
		})


func _update_honeycomb(delta: float) -> void:
	for n in _nodes:
		var p: Vector2 = n["pos"] + n["vel"] * delta
		var v: Vector2 = n["vel"]
		if p.x < 0.0 or p.x > _view.x:
			v.x = -v.x
			p.x = clampf(p.x, 0.0, _view.x)
		if p.y < 0.0 or p.y > _view.y:
			v.y = -v.y
			p.y = clampf(p.y, 0.0, _view.y)
		n["pos"] = p
		n["vel"] = v
	_spawn_left -= delta
	if _spawn_left <= 0.0:
		_spawn_left = 0.12
		_glow[randi() % _hex_centers.size()] = 1.0
	for k in _glow.keys():
		_glow[k] -= delta * 0.5
		if _glow[k] <= 0.0:
			_glow.erase(k)


func _draw_honeycomb() -> void:
	draw_multiline(_hex_lines, Color(BLUE, 0.09), 2.0)

	for k in _glow.keys():
		var center: Vector2 = _hex_centers[k]
		var a: float = _glow[k]
		var pts := PackedVector2Array()
		for i in 6:
			pts.append(center + Vector2.from_angle(PI / 6.0 + i * PI / 3.0) * (HEX_R - 3.0))
		var col := ORANGE if k % 5 == 0 else BLUE
		draw_colored_polygon(pts, Color(col, 0.22 * a))

	var c := _view * 0.5
	for i in 3:
		var p := fposmod(_t * 0.16 + i / 3.0, 1.0)
		draw_arc(c, 60.0 + p * 700.0, 0.0, TAU, 96, Color(BLUE, 0.22 * (1.0 - p)), 3.0, true)

	for i in _nodes.size():
		var pa: Vector2 = _nodes[i]["pos"]
		for j in range(i + 1, _nodes.size()):
			var pb: Vector2 = _nodes[j]["pos"]
			var d := pa.distance_to(pb)
			if d < LINK_DIST:
				draw_line(pa, pb, Color(BLUE, 0.28 * (1.0 - d / LINK_DIST)), 2.0, true)

	for n in _nodes:
		var col2 := ORANGE if n["hot"] else BLUE
		draw_circle(n["pos"], 9.0, Color(col2, 0.15))
		draw_circle(n["pos"], 4.5, Color(col2, 0.85))


# ================= Star flight =================

func _new_star(random_z: bool) -> Dictionary:
	var col := Color.WHITE
	var roll := _rng.randf()
	if roll < 0.12:
		col = ORANGE
	elif roll < 0.5:
		col = BLUE
	return {
		"p": Vector2(_rng.randf_range(-1.0, 1.0), _rng.randf_range(-1.0, 1.0)),
		"z": _rng.randf_range(0.05, 1.0) if random_z else 1.0,
		"c": col,
	}


func _init_stars() -> void:
	_stars.clear()
	for i in STAR_COUNT:
		_stars.append(_new_star(true))


func _update_stars(delta: float) -> void:
	for i in _stars.size():
		var s: Dictionary = _stars[i]
		s["z"] = float(s["z"]) - delta * 0.22
		if s["z"] <= 0.04:
			_stars[i] = _new_star(false)


func _star_pos(s: Dictionary, z: float) -> Vector2:
	var half := _view * 0.5
	return half + Vector2(s["p"].x * half.x, s["p"].y * half.y) * (0.15 / z)


func _draw_stars() -> void:
	for s in _stars:
		var z: float = s["z"]
		var pos := _star_pos(s, z)
		var prev := _star_pos(s, z + 0.04)
		var depth := 1.0 - z
		var alpha := clampf(depth * 1.6, 0.0, 1.0)
		var size := lerpf(0.8, 3.6, depth)
		var col: Color = s["c"]
		draw_line(prev, pos, Color(col, alpha * 0.5), size * 0.8, true)
		draw_circle(pos, size, Color(col, alpha))


# ================= Data rain =================

func _init_rain() -> void:
	_cols.clear()
	var n := int(_view.x / RAIN_COL_W)
	for i in n:
		_cols.append({
			"x": RAIN_COL_W * 0.5 + i * RAIN_COL_W,
			"y": _rng.randf_range(-_view.y, _view.y),
			"v": _rng.randf_range(160.0, 420.0),
			"tail": _rng.randi_range(8, 16),
		})


func _update_rain(delta: float) -> void:
	for c in _cols:
		c["y"] = float(c["y"]) + float(c["v"]) * delta
		if float(c["y"]) - int(c["tail"]) * RAIN_STEP > _view.y:
			c["y"] = -_rng.randf_range(0.0, 400.0)
			c["v"] = _rng.randf_range(160.0, 420.0)
			c["tail"] = _rng.randi_range(8, 16)


func _draw_rain() -> void:
	var pts := PackedVector2Array()
	var cols := PackedColorArray()
	for c in _cols:
		var x: float = c["x"]
		var head: float = c["y"]
		var tail: int = c["tail"]
		for k in tail:
			var y := head - k * RAIN_STEP
			if y < -RAIN_STEP or y > _view.y + RAIN_STEP:
				continue
			var a := 1.0 - float(k) / tail
			var rc := Color(1, 1, 1, 0.9) if k == 0 else Color(BLUE, 0.5 * a)
			pts.append(Vector2(x, y))
			pts.append(Vector2(x, y - 12.0))
			cols.append(rc)
	if pts.size() > 0:
		draw_multiline_colors(pts, cols, 5.0)


# ================= Bubbles =================

func _new_bubble(random_y: bool) -> Dictionary:
	var r := _rng.randf_range(22.0, 95.0)
	var palette := [BLUE, ORANGE, PURPLE]
	return {
		"x": _rng.randf_range(0.0, _view.x),
		"y": _rng.randf_range(0.0, _view.y) if random_y else _view.y + r + 10.0,
		"r": r,
		"v": _rng.randf_range(18.0, 55.0),
		"ph": _rng.randf() * TAU,
		"c": palette[_rng.randi() % 3],
	}


func _init_bubbles() -> void:
	_bubbles.clear()
	for i in BUBBLE_COUNT:
		_bubbles.append(_new_bubble(true))


func _update_bubbles(delta: float) -> void:
	for i in _bubbles.size():
		var b: Dictionary = _bubbles[i]
		b["y"] = float(b["y"]) - float(b["v"]) * delta
		if float(b["y"]) < -float(b["r"]) - 10.0:
			_bubbles[i] = _new_bubble(false)


func _draw_bubbles() -> void:
	for b in _bubbles:
		var r: float = b["r"]
		var col: Color = b["c"]
		var pos := Vector2(float(b["x"]) + sin(_t * 0.6 + float(b["ph"])) * 22.0, b["y"])
		draw_circle(pos, r, Color(col, 0.07))
		draw_arc(pos, r, 0.0, TAU, 40, Color(col, 0.35), 2.5, true)
		draw_arc(pos, r * 0.7, PI * 1.15, PI * 1.5, 12, Color(1, 1, 1, 0.25), 3.0, true)
