extends Control
# Gear icon drawn in code (no font glyph or image import needed).

var color := Color(1, 1, 1)


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(PRESET_FULL_RECT)
	resized.connect(queue_redraw)


func _draw() -> void:
	var c := size * 0.5
	var r_out := minf(size.x, size.y) * 0.36
	var r_in := r_out * 0.76
	var r_hole := r_out * 0.36
	var teeth := 8
	var step := TAU / teeth
	# ring (body of the gear with a hole in the middle)
	draw_arc(c, (r_in + r_hole) * 0.5, 0.0, TAU, 64, color, r_in - r_hole + 1.0, true)
	# teeth
	for i in teeth:
		var a := i * step
		var quad := PackedVector2Array([
			c + Vector2.from_angle(a - step * 0.22) * (r_in - 3.0),
			c + Vector2.from_angle(a - step * 0.15) * r_out,
			c + Vector2.from_angle(a + step * 0.15) * r_out,
			c + Vector2.from_angle(a + step * 0.22) * (r_in - 3.0),
		])
		draw_colored_polygon(quad, color)
