extends Control
# All UI is built in code.
# Screens: lobby (server list), create form, password prompt, room, settings.

const BG_SCRIPT := preload("res://background.gd")
const GEAR_SCRIPT := preload("res://gear_icon.gd")
const CAM_SCRIPT := preload("res://camera_host.gd")
const VOICE_SCRIPT := preload("res://voice.gd")
const SETTINGS_PATH := "user://settings.cfg"
const TG_URL := "https://t.me/sasha123www123"
const TIKTOK_URL := "https://www.tiktok.com/@mrdayni2.0"
const TG_CHANNEL_URL := "https://t.me/lan_rooms"
# Window sizes for Windows (chosen in settings)
const WIN_SIZES := [Vector2i(1366, 768), Vector2i(1360, 768), Vector2i(1280, 768), Vector2i(1280, 720), Vector2i(1280, 600), Vector2i(1024, 768), Vector2i(800, 600)]

const BG := Color(0.06, 0.06, 0.09)
const CARD := Color(0.13, 0.14, 0.2)
const CARD_HI := Color(0.18, 0.2, 0.28)
const ACCENT := Color(0.851, 0.467, 0.341)   # Claude orange
const BLUE := Color(0.427, 0.655, 0.925)
const TIKTOK := Color(0.88, 0.22, 0.45)
const DANGER := Color(0.89, 0.29, 0.29)
const TEXT := Color(0.97, 0.97, 0.98)
const MUTED := Color(0.6, 0.6, 0.66)

var lobby: VBoxContainer
var list_box: VBoxContainer
var create_panel: VBoxContainer
var pw_panel: VBoxContainer
var room_panel: VBoxContainer
var settings_panel: VBoxContainer
var diag_panel: VBoxContainer
var diag_label: Label

var bg_node = null
var cam_host = null
var cam_row: HBoxContainer
var placeholder_tex: Texture2D
var bg_mode := 0
var mode_buttons: Array = []
var win_index := 0
var win_buttons: Array = []

var scan_button: Button
var scanning := false

var name_edit: LineEdit
var pass_edit: LineEdit
var port_edit: LineEdit
var port_scan_button: Button
var ports_scanning := false
var port_option: OptionButton
var port_status: Label
var mic_check: CheckButton
var create_status: Label
var pw_title: Label
var pw_edit: LineEdit
var room_title: Label
var room_info: Label
var preview: TextureRect
var cam_button: Button
var cam_switch_button: Button
var mic_button: Button
var mic_level: ProgressBar
var status_label: Label
var voice = null
var guest_tex: ImageTexture

var pending_ip := ""
var pending_port := 7000
var pending_name := ""
var in_room := false
var is_host := false
var camera_on := false
var front_camera := true
var mic_on := false
var remote_cam_on := false
var guest_frames := 0
# On desktop (Windows) the app can only join servers: the camera is not available there.
var client_only := OS.get_name() != "Android"


func _ready() -> void:
	set_anchors_and_offsets_preset(PRESET_FULL_RECT)
	_load_settings()
	_build_ui()
	if client_only:
		_apply_win_size()
	Net.servers_updated.connect(_on_servers_updated)
	Net.join_result.connect(_on_join_result)
	Net.host_closed.connect(_on_host_closed)
	Net.camera_state_changed.connect(_on_remote_camera)
	Net.video_frame_received.connect(_on_video_frame)
	multiplayer.peer_connected.connect(func(_id): _update_room_info())
	multiplayer.peer_disconnected.connect(func(_id): _update_room_info())
	_show_lobby()


# ---------- Settings storage ----------

func _load_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SETTINGS_PATH) == OK:
		bg_mode = clampi(int(cfg.get_value("background", "mode", 0)), 0, BG_SCRIPT.MODE_NAMES.size() - 1)
		win_index = clampi(int(cfg.get_value("window", "size_index", 0)), 0, WIN_SIZES.size() - 1)


func _save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.load(SETTINGS_PATH)   # keep the other sections (camera)
	cfg.set_value("background", "mode", bg_mode)
	cfg.set_value("window", "size_index", win_index)
	cfg.save(SETTINGS_PATH)


# ---------- UI building ----------

func _build_ui() -> void:
	var bg := ColorRect.new()
	bg.color = BG
	bg.set_anchors_and_offsets_preset(PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)
	bg_node = BG_SCRIPT.new()
	add_child(bg_node)
	bg_node.set_mode(bg_mode)
	cam_host = CAM_SCRIPT.new()
	add_child(cam_host)
	cam_host.frame_ready.connect(func(jpg: PackedByteArray): Net.send_video_frame(jpg))
	voice = VOICE_SCRIPT.new()
	add_child(voice)
	voice.chunk_ready.connect(func(pcm: PackedByteArray): Net.send_voice(pcm))
	Net.voice_received.connect(voice.play_chunk)

	# Lobby
	lobby = _page()
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 20)
	lobby.add_child(head)
	var title := _label("Серверы в сети", 56, TEXT)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(title)
	head.add_child(_gear_button())
	var actions := HBoxContainer.new()
	actions.add_theme_constant_override("separation", 20)
	lobby.add_child(actions)
	scan_button = _button("Сканировать", 130, BLUE, 42, _on_scan_pressed)
	scan_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	actions.add_child(scan_button)
	if not client_only:
		var plus := _button("+", 130, ACCENT, 80, _show_create)
		plus.custom_minimum_size = Vector2(170, 130)
		actions.add_child(plus)
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	lobby.add_child(scroll)
	list_box = VBoxContainer.new()
	list_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list_box.add_theme_constant_override("separation", 22)
	scroll.add_child(list_box)
	if client_only:
		var note := _label("В этой версии приложение хостить невозможно: на Windows камера не работает. Подключайся к серверам с телефона, слушай и говори в голосовом чате.", 30, MUTED)
		note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		lobby.add_child(note)

	# Create server
	create_panel = _page()
	create_panel.add_theme_constant_override("separation", 20)
	create_panel.add_child(_button("Назад", 100, CARD, 38, _show_lobby))
	create_panel.add_child(_label("Новый сервер", 48, TEXT))
	name_edit = _line_edit("Имя сервера")
	create_panel.add_child(name_edit)
	pass_edit = _line_edit("Пароль (необязательно)")
	pass_edit.secret = true
	create_panel.add_child(pass_edit)
	create_panel.add_child(_label("Порт сервера (1024-65535)", 32, MUTED))
	var port_row := HBoxContainer.new()
	port_row.add_theme_constant_override("separation", 16)
	create_panel.add_child(port_row)
	port_edit = _line_edit("Впиши порт")
	port_edit.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_NUMBER
	port_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	port_row.add_child(port_edit)
	port_scan_button = _button("Скан портов", 120, BLUE, 34, _scan_ports)
	port_row.add_child(port_scan_button)
	port_option = OptionButton.new()
	port_option.custom_minimum_size = Vector2(0, 110)
	port_option.add_theme_font_size_override("font_size", 40)
	port_option.item_selected.connect(func(idx: int): port_edit.text = str(port_option.get_item_id(idx)))
	create_panel.add_child(port_option)
	port_status = _label("", 30, MUTED)
	create_panel.add_child(port_status)
	mic_check = CheckButton.new()
	mic_check.text = "Микрофон: выкл (не слышат)"
	mic_check.add_theme_font_size_override("font_size", 38)
	mic_check.toggled.connect(func(on: bool):
		mic_check.text = "Микрофон: вкл (слышат)" if on else "Микрофон: выкл (не слышат)")
	create_panel.add_child(mic_check)
	create_panel.add_child(_label("Для создания сервера нужен доступ к камере.", 30, MUTED))
	create_status = _label("", 32, DANGER)
	create_panel.add_child(create_status)
	var spacer := Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	create_panel.add_child(spacer)
	create_panel.add_child(_button("Создать сервер", 140, ACCENT, 46, _on_create_pressed))

	# Password prompt
	pw_panel = _page()
	pw_title = _label("Пароль", 52, TEXT)
	pw_panel.add_child(pw_title)
	pw_edit = _line_edit("Пароль")
	pw_edit.secret = true
	pw_panel.add_child(pw_edit)
	pw_panel.add_child(_button("Войти", 130, BLUE, 44, func(): _join(pending_ip, pw_edit.text)))
	pw_panel.add_child(_button("Отмена", 120, CARD, 38, _show_lobby))

	# Room (host or guest)
	room_panel = _page()
	room_title = _label("", 56, TEXT)
	room_panel.add_child(room_title)
	room_info = _label("", 32, MUTED)
	room_panel.add_child(room_info)
	status_label = _label("", 26, BLUE)
	room_panel.add_child(status_label)
	var frame := PanelContainer.new()
	frame.add_theme_stylebox_override("panel", _sb(CARD, 40))
	frame.size_flags_vertical = Control.SIZE_EXPAND_FILL
	room_panel.add_child(frame)
	preview = TextureRect.new()
	placeholder_tex = _placeholder_texture()
	preview.texture = placeholder_tex
	preview.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	preview.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	frame.add_child(preview)
	# Camera (host only) and microphone (everyone) side by side
	var media_row := HBoxContainer.new()
	media_row.add_theme_constant_override("separation", 20)
	room_panel.add_child(media_row)
	cam_button = _button("Камера: выкл", 130, BLUE, 38, _toggle_camera)
	cam_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	media_row.add_child(cam_button)
	mic_button = _button("Микрофон: выкл", 130, CARD_HI, 38, _toggle_mic)
	mic_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	media_row.add_child(mic_button)
	mic_level = ProgressBar.new()
	mic_level.max_value = 1.0
	mic_level.show_percentage = false
	mic_level.custom_minimum_size = Vector2(0, 16)
	var lvl_bg := _sb(CARD, 8)
	lvl_bg.set_content_margin_all(0)
	var lvl_fill := _sb(ACCENT, 8)
	lvl_fill.set_content_margin_all(0)
	mic_level.add_theme_stylebox_override("background", lvl_bg)
	mic_level.add_theme_stylebox_override("fill", lvl_fill)
	mic_level.visible = false
	room_panel.add_child(mic_level)
	cam_row = HBoxContainer.new()
	cam_row.add_theme_constant_override("separation", 16)
	room_panel.add_child(cam_row)
	cam_switch_button = _button("Фронт / тыл", 110, CARD_HI, 32, _switch_camera)
	cam_switch_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cam_row.add_child(cam_switch_button)
	var rot_btn := _button("Повернуть", 110, CARD_HI, 32, func(): cam_host.rotate_view())
	rot_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cam_row.add_child(rot_btn)
	var mir_btn := _button("Зеркало", 110, CARD_HI, 32, func(): cam_host.toggle_mirror())
	mir_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cam_row.add_child(mir_btn)
	room_panel.add_child(_button("Закрыть / выйти", 120, DANGER, 38, _leave_room))

	# Settings
	settings_panel = _page()
	settings_panel.add_child(_button("Назад", 110, CARD, 38, _show_lobby))
	settings_panel.add_child(_label("Настройки", 52, TEXT))
	settings_panel.add_child(_label("Живые обои", 36, MUTED))
	var sscroll := ScrollContainer.new()
	sscroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	settings_panel.add_child(sscroll)
	var mode_box := VBoxContainer.new()
	mode_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	mode_box.add_theme_constant_override("separation", 18)
	sscroll.add_child(mode_box)
	for i in BG_SCRIPT.MODE_NAMES.size():
		var mb := _button(BG_SCRIPT.MODE_NAMES[i], 120, CARD, 40)
		mb.pressed.connect(_set_bg_mode.bind(i))
		mode_box.add_child(mb)
		mode_buttons.append(mb)
	var custom := _button("Свои обои из .json - скоро", 120, CARD, 34)
	custom.disabled = true
	mode_box.add_child(custom)
	if client_only:
		_build_win_size_ui(mode_box)
	mode_box.add_child(_label("Сеть", 36, MUTED))
	mode_box.add_child(_button("Диагностика сети", 120, CARD_HI, 38, _show_diag))
	settings_panel.add_child(_label("Контакты", 34, MUTED))
	settings_panel.add_child(_button("Telegram-канал LAN Rooms", 120, BLUE, 38, func(): OS.shell_open(TG_CHANNEL_URL)))
	settings_panel.add_child(_button("Telegram  @sasha123www123", 120, BLUE, 38, func(): OS.shell_open(TG_URL)))
	settings_panel.add_child(_button("TikTok  @mrdayni2.0", 120, TIKTOK, 38, func(): OS.shell_open(TIKTOK_URL)))

	# Network diagnostics
	diag_panel = _page()
	diag_panel.add_child(_button("Назад", 110, CARD, 38, _show_settings))
	diag_panel.add_child(_label("Диагностика сети", 52, TEXT))
	var dscroll := ScrollContainer.new()
	dscroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	diag_panel.add_child(dscroll)
	diag_label = _label("", 34, TEXT)
	diag_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	dscroll.add_child(diag_label)
	diag_panel.add_child(_button("Проверить ещё раз", 120, BLUE, 38, _run_diag))

	# Refreshes the room status line and the microphone level several times a second
	var tick := Timer.new()
	tick.wait_time = 0.2
	tick.autostart = true
	tick.timeout.connect(_ui_tick)
	add_child(tick)


# A full-screen page: margins + vertical box. Pages are hidden/shown via the VBox.
func _page() -> VBoxContainer:
	var m := MarginContainer.new()
	m.set_anchors_and_offsets_preset(PRESET_FULL_RECT)
	# All pages overlap full-screen; the wrapper must not swallow taps meant for the visible page.
	m.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for side in ["margin_left", "margin_right"]:
		m.add_theme_constant_override(side, 36)
	m.add_theme_constant_override("margin_top", 60)
	m.add_theme_constant_override("margin_bottom", 48)
	add_child(m)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 28)
	m.add_child(v)
	return v


func _label(text: String, size: int, color: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l


func _line_edit(hint: String) -> LineEdit:
	var e := LineEdit.new()
	e.placeholder_text = hint
	e.custom_minimum_size = Vector2(0, 110)
	e.add_theme_font_size_override("font_size", 40)
	e.add_theme_stylebox_override("normal", _sb(CARD, 28))
	e.add_theme_stylebox_override("focus", _sb(CARD_HI, 28))
	return e


func _sb(color: Color, radius := 32) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = color
	s.set_corner_radius_all(radius)
	s.content_margin_left = 30
	s.content_margin_right = 30
	s.content_margin_top = 18
	s.content_margin_bottom = 18
	return s


func _style_button(b: Button, color: Color) -> void:
	b.add_theme_stylebox_override("normal", _sb(color))
	b.add_theme_stylebox_override("hover", _sb(color.lightened(0.1)))
	b.add_theme_stylebox_override("pressed", _sb(color.darkened(0.2)))
	b.add_theme_stylebox_override("focus", _sb(color))
	b.add_theme_stylebox_override("disabled", _sb(color.darkened(0.45)))


func _button(text: String, height: int, color: Color, font: int, on_press := Callable()) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, height)
	b.add_theme_font_size_override("font_size", font)
	b.add_theme_color_override("font_color", TEXT)
	b.add_theme_color_override("font_hover_color", TEXT)
	b.add_theme_color_override("font_disabled_color", MUTED)
	_style_button(b, color)
	if on_press.is_valid():
		b.pressed.connect(on_press)
	return b


func _gear_button() -> Button:
	var b := _button("", 130, CARD_HI, 40, _show_settings)
	b.custom_minimum_size = Vector2(130, 130)
	var g = GEAR_SCRIPT.new()
	g.color = TEXT
	b.add_child(g)
	return b


func _placeholder_texture() -> Texture2D:
	var img := Image.create(640, 480, false, Image.FORMAT_RGBA8)
	img.fill(Color(0.1, 0.1, 0.14))
	return ImageTexture.create_from_image(img)


# ---------- Screens ----------

func _hide_all() -> void:
	lobby.visible = false
	create_panel.visible = false
	pw_panel.visible = false
	room_panel.visible = false
	settings_panel.visible = false
	diag_panel.visible = false


func _show_lobby() -> void:
	in_room = false
	_hide_all()
	lobby.visible = true
	Net.start_discovery()
	_on_servers_updated(Net.current_servers())


func _show_settings() -> void:
	_hide_all()
	settings_panel.visible = true
	_refresh_mode_buttons()


func _show_diag() -> void:
	_hide_all()
	diag_panel.visible = true
	_run_diag()


func _run_diag() -> void:
	diag_label.text = "\n\n".join(PackedStringArray(Net.run_diagnostics()))


func _show_create() -> void:
	_hide_all()
	create_panel.visible = true
	name_edit.text = ""
	pass_edit.text = ""
	create_status.text = ""
	_scan_ports()


func _show_room(title: String, host: bool) -> void:
	in_room = true
	is_host = host
	_hide_all()
	room_panel.visible = true
	room_title.text = title
	camera_on = false
	remote_cam_on = false
	guest_frames = 0
	cam_button.text = "Камера: выкл"
	cam_button.visible = host
	cam_row.visible = host
	preview.texture = placeholder_tex
	guest_tex = null
	mic_on = false
	_refresh_mic_button()
	_update_room_info()
	# The mic switch from the create form: "on" means the host is heard from the start.
	if host and Net.mic_enabled:
		_set_mic(true)


func _update_room_info() -> void:
	if not in_room:
		return
	var mic := "вкл" if mic_on else "выкл"
	if is_host:
		room_info.text = "Ты хост • порт %d • в сервере: %d • твой микрофон: %s" % [Net.port, multiplayer.get_peers().size(), mic]
	else:
		var cam := "вкл" if remote_cam_on else "выкл"
		room_info.text = "Ты подключён • камера хоста: %s • твой микрофон: %s" % [cam, mic]


# ---------- Settings: live wallpapers ----------

func _set_bg_mode(i: int) -> void:
	bg_mode = i
	bg_node.set_mode(i)
	_save_settings()
	_refresh_mode_buttons()


func _refresh_mode_buttons() -> void:
	for i in mode_buttons.size():
		var b: Button = mode_buttons[i]
		var selected := i == bg_mode
		b.text = BG_SCRIPT.MODE_NAMES[i] + ("  (выбрано)" if selected else "")
		_style_button(b, ACCENT if selected else CARD)


# ---------- Create ----------

func _scan_ports() -> void:
	if ports_scanning:
		return
	ports_scanning = true
	port_scan_button.disabled = true
	port_option.clear()
	port_option.disabled = true
	port_status.text = "Ищу свободные порты (1024-10000)..."
	var free: Array = await Net.scan_free_ports(1024, 10000, 80)
	ports_scanning = false
	port_scan_button.disabled = false
	port_option.clear()
	for p in free:
		port_option.add_item("Порт %d" % p, p)
	if free.is_empty():
		port_status.text = "Свободных портов не найдено. Открой Настройки - Диагностика сети (возможно, нет разрешения Internet)"
	else:
		port_option.select(0)
		port_status.text = "Свободно портов: %d. Выбери из списка или впиши свой" % free.size()
		if port_edit.text.strip_edges() == "":
			port_edit.text = str(free[0])
	port_option.disabled = free.is_empty()


func _on_create_pressed() -> void:
	var sname := name_edit.text.strip_edges()
	if sname == "":
		create_status.text = "Введи имя сервера"
		return
	var txt := port_edit.text.strip_edges()
	if not txt.is_valid_int():
		create_status.text = "Впиши порт числом или нажми «Скан портов»"
		return
	var port := int(txt)
	if port < 1024 or port > 65535 or port == Net.DISCOVERY_PORT:
		create_status.text = "Порт должен быть от 1024 до 65535 (кроме %d)" % Net.DISCOVERY_PORT
		return
	if not _camera_permitted():
		create_status.text = "Разреши доступ к камере и нажми «Создать» ещё раз"
		return
	var err := Net.start_hosting(sname, pass_edit.text, mic_check.button_pressed, port)
	if err != OK:
		var hint := " Если ошибка 20 на любом порту - проверь разрешение Internet в экспорте (Настройки - Диагностика сети)." if err == ERR_CANT_CREATE else ""
		create_status.text = "Порт %d не открылся (код %d). Выбери другой порт.%s" % [port, err, hint]
		_scan_ports()
		return
	_show_room(sname, true)


# ---------- Lobby list & joining ----------

func _on_scan_pressed() -> void:
	if scanning:
		return
	scanning = true
	scan_button.disabled = true
	scan_button.text = "Сканирую..."
	Net.rescan()
	_on_servers_updated({})
	await get_tree().create_timer(2.5).timeout
	scanning = false
	scan_button.disabled = false
	scan_button.text = "Сканировать"
	if lobby.visible:
		_on_servers_updated(Net.current_servers())


func _on_servers_updated(servers: Dictionary) -> void:
	if not lobby.visible:
		return
	for c in list_box.get_children():
		list_box.remove_child(c)
		c.queue_free()
	if servers.is_empty():
		var msg := "Ищу серверы в сети..." if scanning else ("Серверов пока нет.\nНажми «Сканировать», чтобы поискать ещё" if client_only else "Серверов пока нет.\nНажми «Сканировать», чтобы поискать ещё, или + чтобы создать свой")
		var hint := _label(msg, 36, MUTED)
		hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		hint.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		hint.custom_minimum_size = Vector2(0, 360)
		list_box.add_child(hint)
		return
	for ip in servers.keys():
		var info: Dictionary = servers[ip]
		var lock := "  •  пароль" if info.get("pw", false) else ""
		var text := "%s\n%d чел.  •  порт %d%s" % [str(info.get("name", "?")), int(info.get("players", 0)), int(info.get("port", 7000)), lock]
		var card := _button(text, 200, CARD, 40)
		card.pressed.connect(_on_server_pressed.bind(ip, info))
		list_box.add_child(card)


func _on_server_pressed(ip: String, info: Dictionary) -> void:
	pending_ip = ip
	pending_port = int(info.get("port", 7000))
	pending_name = str(info.get("name", "Сервер"))
	if info.get("pw", false):
		lobby.visible = false
		pw_panel.visible = true
		pw_title.text = "Пароль: " + pending_name
		pw_edit.text = ""
	else:
		_join(pending_ip, "")


func _join(ip: String, pw: String) -> void:
	Net.join_server(ip, pending_port, pw)


func _on_join_result(ok: bool, msg: String) -> void:
	if ok:
		_show_room(pending_name, false)
	else:
		_alert(msg)
		_show_lobby()


func _on_host_closed() -> void:
	_alert("Хост закрыл сервер")
	_leave_room()


func _on_remote_camera(on: bool) -> void:
	if in_room and not is_host:
		remote_cam_on = on
		if not on:
			preview.texture = placeholder_tex
			guest_tex = null
		_update_room_info()


# Guests: show the JPEG frames sent by the host.
func _on_video_frame(jpg: PackedByteArray) -> void:
	if not in_room or is_host:
		return
	var img := Image.new()
	if img.load_jpg_from_buffer(jpg) != OK:
		return
	guest_frames += 1
	if guest_tex != null and guest_tex.get_size() == Vector2(img.get_size()):
		guest_tex.update(img)
	else:
		guest_tex = ImageTexture.create_from_image(img)
	preview.texture = guest_tex


# ---------- Room controls ----------

func _leave_room() -> void:
	if camera_on:
		cam_host.stop()
		camera_on = false
	voice.stop_all()
	mic_on = false
	preview.texture = placeholder_tex
	guest_tex = null
	Net.leave()
	_show_lobby()


# Status line under the room info: camera state, who is speaking. Also the microphone level bar.
func _ui_tick() -> void:
	if not in_room:
		return
	mic_level.visible = mic_on
	if mic_on:
		mic_level.value = voice.level
	var parts: Array = []
	if is_host and camera_on:
		var cs: String = cam_host.status_text()
		if cs != "":
			parts.append(cs)
	if not is_host and remote_cam_on:
		parts.append("Получено кадров от хоста: %d" % guest_frames)
	var who: PackedStringArray = voice.speaking_names()
	if not who.is_empty():
		parts.append("Говорит: " + ", ".join(who))
	status_label.text = "\n".join(PackedStringArray(parts))


func _refresh_mic_button() -> void:
	mic_button.text = "Микрофон: вкл" if mic_on else "Микрофон: выкл"
	_style_button(mic_button, ACCENT if mic_on else CARD_HI)


func _toggle_mic() -> void:
	_set_mic(not mic_on)


func _set_mic(on: bool) -> void:
	if on == mic_on:
		return
	if on:
		mic_button.disabled = true
		var err: String = await voice.start_mic()
		mic_button.disabled = false
		if not in_room:
			voice.stop_mic()
			return
		if err != "":
			room_info.text = err
			if is_host:
				Net.mic_enabled = false
			return
		mic_on = true
	else:
		voice.stop_mic()
		mic_on = false
	if is_host:
		Net.mic_enabled = mic_on
	_refresh_mic_button()
	_update_room_info()


func _toggle_camera() -> void:
	if camera_on:
		cam_host.stop()
		camera_on = false
		cam_button.text = "Камера: выкл"
		preview.texture = placeholder_tex
		Net.set_camera_state(false)
		_update_room_info()
		return
	if not _camera_permitted():
		room_info.text = "Разреши доступ к камере и нажми ещё раз"
		return
	cam_button.disabled = true
	room_info.text = "Включаю камеру..."
	var err: String = await cam_host.start(front_camera)
	cam_button.disabled = false
	if err != "":
		room_info.text = err
		return
	camera_on = true
	cam_button.text = "Камера: вкл"
	preview.texture = cam_host.preview_texture()
	Net.set_camera_state(true)
	_update_room_info()


func _switch_camera() -> void:
	front_camera = not front_camera
	if not camera_on:
		return
	room_info.text = "Переключаю камеру..."
	var err: String = await cam_host.start(front_camera)
	if err != "":
		camera_on = false
		cam_button.text = "Камера: выкл"
		preview.texture = placeholder_tex
		Net.set_camera_state(false)
		room_info.text = err
		return
	_update_room_info()


# ---------- Window size (Windows only) ----------

func _build_win_size_ui(parent: VBoxContainer) -> void:
	parent.add_child(_label("Разрешение окна", 36, MUTED))
	for i in WIN_SIZES.size():
		var b := _button("", 110, CARD, 38)
		b.pressed.connect(_set_win_size.bind(i))
		parent.add_child(b)
		win_buttons.append(b)
	_refresh_win_buttons()


func _set_win_size(i: int) -> void:
	win_index = i
	_apply_win_size()
	_save_settings()
	_refresh_win_buttons()


func _apply_win_size() -> void:
	# The editor's embedded window cannot be resized from code; the size applies in the exported build.
	if OS.has_feature("editor"):
		return
	var s: Vector2i = WIN_SIZES[win_index]
	DisplayServer.window_set_size(s)
	var screen := DisplayServer.screen_get_size()
	DisplayServer.window_set_position((screen - s) / 2)


func _refresh_win_buttons() -> void:
	for i in win_buttons.size():
		var b: Button = win_buttons[i]
		var s: Vector2i = WIN_SIZES[i]
		var selected := i == win_index
		b.text = "%d × %d" % [s.x, s.y] + ("  (выбрано)" if selected else "")
		_style_button(b, ACCENT if selected else CARD)


# ---------- Helpers ----------

func _camera_permitted() -> bool:
	if OS.get_name() != "Android":
		return true
	if "android.permission.CAMERA" in OS.get_granted_permissions():
		return true
	OS.request_permissions()
	return false


func _alert(text: String) -> void:
	var d := AcceptDialog.new()
	d.dialog_text = text
	add_child(d)
	d.confirmed.connect(d.queue_free)
	d.canceled.connect(d.queue_free)
	d.popup_centered()
