extends Node
# Host camera for LAN Rooms.
# Uses Godot's CameraServer (camera on Android needs Godot 4.5 or newer).
# The camera image is converted to RGB by a shader inside a small SubViewport.
# That viewport is both the local preview and the source of the JPEG frames sent to guests.
#
# Orientation: Godot gives a rotation for the feed (feed_transform). Because the exact
# direction can differ between phones, the user can also rotate/mirror the picture by hand.
# Those manual choices are saved per camera (front / back) in user://settings.cfg.

signal frame_ready(jpg: PackedByteArray)

const VIEW_SIZE := Vector2i(288, 384)   # portrait 3:4
const FRAME_INTERVAL := 0.12            # ~8 frames per second
const JPG_QUALITY := 0.6
const SETTINGS_PATH := "user://settings.cfg"

const SHADER_CODE := """
shader_type canvas_item;

uniform sampler2D tex_a : filter_linear, repeat_disable;
uniform sampler2D tex_b : filter_linear, repeat_disable;
uniform int mode = 0;       // 0 = RGB in tex_a, 1 = Y in tex_a + CbCr in tex_b, 2 = YCbCr packed in tex_a
uniform vec2 inv_x = vec2(1.0, 0.0);   // inverse of the feed transform (linear part)
uniform vec2 inv_y = vec2(0.0, 1.0);
uniform vec2 crop = vec2(1.0, 1.0);    // cut the edges so the picture is not stretched
uniform int turns = 0;                 // manual quarter turns
uniform bool mirror = false;

vec3 ycbcr_to_rgb(float y, float cb, float cr) {
	cb -= 0.5;
	cr -= 0.5;
	return vec3(y + 1.402 * cr, y - 0.344136 * cb - 0.714136 * cr, y + 1.772 * cb);
}

void fragment() {
	vec2 uv = (UV - 0.5) * crop + 0.5;
	if (mirror) {
		uv.x = 1.0 - uv.x;
	}
	if (turns == 1) {
		uv = vec2(1.0 - uv.y, uv.x);
	} else if (turns == 2) {
		uv = vec2(1.0 - uv.x, 1.0 - uv.y);
	} else if (turns == 3) {
		uv = vec2(uv.y, 1.0 - uv.x);
	}
	vec2 d = uv - 0.5;
	vec2 suv = clamp(inv_x * d.x + inv_y * d.y + 0.5, vec2(0.0), vec2(1.0));
	vec3 rgb;
	if (mode == 1) {
		float y = texture(tex_a, suv).r;
		vec2 cc = texture(tex_b, suv).rg;
		rgb = ycbcr_to_rgb(y, cc.x, cc.y);
	} else if (mode == 2) {
		vec3 t = texture(tex_a, suv).rgb;
		rgb = ycbcr_to_rgb(t.r, t.g, t.b);
	} else {
		rgb = texture(tex_a, suv).rgb;
	}
	COLOR = vec4(clamp(rgb, vec3(0.0), vec3(1.0)), 1.0);
}
"""

var _vp: SubViewport
var _mat: ShaderMaterial
var _feed = null
var _tex_a: CameraTexture
var _tex_b: CameraTexture
var _active := false
var _front := true
var _frame_seen := false
var _frames := 0
var _sent := 0
var _since_start := 0.0
var _accum := 0.0
var _src_w := 640
var _src_h := 480
var _feed_name := ""
var _format_text := ""
var _turns := {true: 0, false: 0}
var _mirror := {true: false, false: false}


func _ready() -> void:
	_load_manual()
	_vp = SubViewport.new()
	_vp.size = VIEW_SIZE
	_vp.disable_3d = true
	_vp.render_target_update_mode = SubViewport.UPDATE_DISABLED
	add_child(_vp)
	var shader := Shader.new()
	shader.code = SHADER_CODE
	_mat = ShaderMaterial.new()
	_mat.shader = shader
	var rect := ColorRect.new()
	_vp.add_child(rect)
	rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	rect.size = Vector2(VIEW_SIZE)
	rect.material = _mat


func preview_texture() -> Texture2D:
	return _vp.get_texture()


func is_active() -> bool:
	return _active


# One line with the camera state, shown in the room. Helps to see what is wrong if the picture is missing.
func status_text() -> String:
	if not _active:
		return ""
	if _frames == 0:
		return "Камера включена, жду кадры... (%s)" % _feed_name
	return "%s • %s • кадров: %d • отправлено: %d" % [_feed_name, _format_text, _frames, _sent]


# Rotate the picture by 90 degrees (use if the image comes out sideways).
func rotate_view() -> void:
	_turns[_front] = (int(_turns[_front]) + 1) % 4
	_save_manual()


# Mirror the picture (use if the image comes out flipped).
func toggle_mirror() -> void:
	_mirror[_front] = not _mirror[_front]
	_save_manual()


func _load_manual() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SETTINGS_PATH) != OK:
		return
	for front in [true, false]:
		var key := "front" if front else "back"
		_turns[front] = clampi(int(cfg.get_value("camera", "turns_" + key, 0)), 0, 3)
		_mirror[front] = bool(cfg.get_value("camera", "mirror_" + key, false))


func _save_manual() -> void:
	var cfg := ConfigFile.new()
	cfg.load(SETTINGS_PATH)   # keep the other settings
	for front in [true, false]:
		var key := "front" if front else "back"
		cfg.set_value("camera", "turns_" + key, _turns[front])
		cfg.set_value("camera", "mirror_" + key, _mirror[front])
	cfg.save(SETTINGS_PATH)


# Starts the camera. Returns "" on success or a text with the reason on failure.
func start(front: bool) -> String:
	_deactivate()
	_front = front
	CameraServer.set("monitoring_feeds", true)   # Godot 4.5+; ignored on older versions
	var feed = null
	var waited := 0.0
	while waited < 4.0:
		feed = _find_feed(front, waited >= 1.5)
		if feed != null:
			break
		await get_tree().create_timer(0.25).timeout
		waited += 0.25
	if feed == null:
		CameraServer.set("monitoring_feeds", false)
		return _no_camera_message()

	var formats: Array = feed.get_formats()
	if formats.is_empty():
		CameraServer.set("monitoring_feeds", false)
		return "У камеры нет доступных форматов"
	var fmt_index := _pick_format(formats)
	if not feed.set_format(fmt_index, {}):
		CameraServer.set("monitoring_feeds", false)
		return "Не удалось выбрать формат камеры"
	var fmt: Dictionary = formats[fmt_index] if typeof(formats[fmt_index]) == TYPE_DICTIONARY else {}
	_src_w = maxi(1, int(fmt.get("width", 640)))
	_src_h = maxi(1, int(fmt.get("height", 480)))
	_format_text = "%dx%d" % [_src_w, _src_h]
	_feed_name = str(feed.get_name())
	feed.feed_is_active = true
	if not feed.feed_is_active:
		CameraServer.set("monitoring_feeds", false)
		return "Камера не включилась. Проверь, что у приложения есть разрешение «Камера»"

	_feed = feed
	_tex_a = CameraTexture.new()
	_tex_a.camera_feed_id = feed.get_id()
	_tex_a.set("which_feed", 0)   # RGBA / Y / YCbCr image
	_tex_b = CameraTexture.new()
	_tex_b.camera_feed_id = feed.get_id()
	_tex_b.set("which_feed", 1)   # CbCr image
	_mat.set_shader_parameter("tex_a", _tex_a)
	_mat.set_shader_parameter("tex_b", _tex_b)
	if feed.has_signal("frame_changed") and not feed.is_connected("frame_changed", _on_frame):
		feed.connect("frame_changed", _on_frame)
	_frame_seen = false
	_frames = 0
	_sent = 0
	_since_start = 0.0
	_accum = 0.0
	_active = true
	_vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	return ""


# Turns the camera off completely.
func stop() -> void:
	var was_active := _active
	_deactivate()
	if was_active:
		CameraServer.set("monitoring_feeds", false)


# Stops the current feed but keeps the camera list (used when switching front/back).
func _deactivate() -> void:
	if _feed != null:
		if _feed.has_signal("frame_changed") and _feed.is_connected("frame_changed", _on_frame):
			_feed.disconnect("frame_changed", _on_frame)
		_feed.feed_is_active = false
		_feed = null
	_active = false
	_frame_seen = false
	if _vp:
		_vp.render_target_update_mode = SubViewport.UPDATE_DISABLED


func _on_frame() -> void:
	_frame_seen = true
	_frames += 1


func _find_feed(front: bool, allow_fallback: bool):
	var wanted := 1 if front else 2   # FEED_FRONT = 1, FEED_BACK = 2
	var fallback = null
	for f in CameraServer.feeds():
		if f.get_position() == wanted:
			return f
		if fallback == null:
			fallback = f
	return fallback if allow_fallback else null


# Prefers a 4:3 format with a width close to 640 (small, and fits the portrait view without stretching).
func _pick_format(formats: Array) -> int:
	var best := 0
	var best_score := 1 << 30
	for i in formats.size():
		if typeof(formats[i]) != TYPE_DICTIONARY:
			continue
		var w := int(formats[i].get("width", 0))
		var h := maxi(1, int(formats[i].get("height", 1)))
		var score := absi(w - 640)
		if absf(float(w) / float(h) - 4.0 / 3.0) > 0.05:
			score += 2000
		if score < best_score:
			best_score = score
			best = i
	return best


func _no_camera_message() -> String:
	var v := Engine.get_version_info()
	if int(v["hex"]) < 0x040500:
		return "Камера на Android работает только в Godot 4.5 и новее. Сейчас Godot %d.%d.%d" % [v["major"], v["minor"], v["patch"]]
	return "Камеры не найдены. Проверь разрешение «Камера» (и в экспорте галочку CAMERA) и что камеру не занимает другое приложение"


# Rotation of the feed in quarter turns, taken from feed_transform.
func _feed_quarter_turns(t: Transform2D) -> int:
	return posmod(roundi(atan2(t.x.y, t.x.x) / (PI / 2.0)), 4)


func _process(delta: float) -> void:
	if not _active or _feed == null:
		return
	_since_start += delta
	var t: Transform2D = _feed.feed_transform
	# The shader samples the camera image, so it needs the inverse of the picture transform.
	var inv := Transform2D(t.x, t.y, Vector2.ZERO).affine_inverse()
	_mat.set_shader_parameter("inv_x", inv.x)
	_mat.set_shader_parameter("inv_y", inv.y)
	var turns: int = _turns[_front]
	_mat.set_shader_parameter("turns", turns)
	_mat.set_shader_parameter("mirror", _mirror[_front])
	# Aspect of the upright picture decides which edges get cropped.
	var odd := (_feed_quarter_turns(t) + turns) % 2 == 1
	var ar := float(_src_h) / float(_src_w) if odd else float(_src_w) / float(_src_h)
	var view_ar := float(VIEW_SIZE.x) / float(VIEW_SIZE.y)
	if ar > view_ar:
		_mat.set_shader_parameter("crop", Vector2(view_ar / ar, 1.0))
	else:
		_mat.set_shader_parameter("crop", Vector2(1.0, ar / view_ar))
	var dt: int = _feed.get_datatype()
	_mat.set_shader_parameter("mode", 1 if dt == 3 else (2 if dt == 2 else 0))
	_accum += delta
	if _accum < FRAME_INTERVAL:
		return
	# Do not send empty frames before the first real camera frame arrives
	# (if the frame signal never fires, start sending anyway after 2 seconds).
	if not _frame_seen and _since_start < 2.0:
		return
	_accum = 0.0
	var img := _vp.get_texture().get_image()
	if img == null or img.is_empty():
		return
	img.convert(Image.FORMAT_RGB8)
	_sent += 1
	frame_ready.emit(img.save_jpg_to_buffer(JPG_QUALITY))
