# LAN Rooms (Godot 4.5+, built for 4.7)

Status: the code has NOT been run in Godot or on a phone yet. Camera, voice and the port scan are untested on real devices.

Mobile app: a list of servers found on the same network (Wi-Fi or your phone's hotspot).
- **+** creates a server: name, optional password, port (scan or type your own), mic on/off, **Create**.
- **Сканировать** (main menu) looks for new hosts without restarting the app.
- **Gear** opens settings: live wallpaper modes, network diagnostics, contact links (Telegram channel https://t.me/lan_rooms, Telegram @sasha123www123, TikTok @mrdayni2.0).
- In a room the host can turn the camera on/off and switch front/back camera. Guests see the picture.
- **Voice chat**: the "Микрофон" button next to the camera button works for everyone (host and guests). Guests start muted; the host starts with the switch from the create form.

## Windows version
The same project, exported as Windows Desktop (Project -> Export -> Windows Desktop). On Windows the **+** button is hidden and a note at the bottom says that hosting is not possible in this version. You can join servers, see the list and use voice chat. Hosting and the camera need Android. Windows Firewall may ask for access on the first launch: allow it for private networks.

## Files
- `project.godot` - project settings (portrait, 720x1600, Mobile renderer, autoload `Net`, icon, `audio/driver/enable_input=true` for the microphone)
- `main.tscn` / `main.gd` - all UI (lobby, create form, password prompt, room, settings)
- `net.gd` - autoload: UDP broadcast discovery (port 7001), ENet hosting/joining on the chosen port, password check, port scan, video and voice RPCs
- `camera_host.gd` - host camera: Godot CameraServer -> shader (YCbCr to RGB) -> JPEG frames sent to guests
- `voice.gd` - voice chat: microphone capture -> 16 kHz mono PCM chunks -> playback of every speaker
- `background.gd` - live wallpaper modes (honeycomb, star flight, data rain, bubbles, off)
- `gear_icon.gd` - gear icon drawn in code
- `icon.svg` - app icon

Settings are saved in `user://settings.cfg` (wallpaper mode, manual camera rotation/mirror for front and back camera). Custom wallpapers from `.json` files are planned for later.

## Build for Android
1. Install Godot 4.5 or newer (4.7 is fine), open the folder as a project.
2. Install the Android build template and export templates.
3. Project -> Export -> Android. Enable permissions:
   `INTERNET`, `ACCESS_NETWORK_STATE`, `ACCESS_WIFI_STATE`, `CHANGE_WIFI_MULTICAST_STATE`, `CAMERA`, `RECORD_AUDIO`.
4. Install the SAME build on all phones (the RPC list changed, old builds will not connect to this one).

## How voice works
Every phone sends its microphone to the host, the host passes it to the other guests (and plays it itself). Only speech is sent (silence is skipped). The bar under the buttons shows your microphone level; the line above it shows who is speaking. Use headphones, otherwise the phone speaker is picked up by the microphone and you get an echo.

## Camera notes
- If the picture is sideways or upside down, press "Повернуть" (can be pressed several times); "Зеркало" flips it. The choice is saved separately for the front and back camera.
- The line above the buttons shows the camera name, resolution, frames received and frames sent. If it says it is waiting for frames and nothing comes, send that line to the developer.

## Not finished
- Not run in Godot in this environment; expect small fixes on first launch (camera orientation and microphone are the most device-dependent parts).
- Custom live wallpapers from `.json`.
